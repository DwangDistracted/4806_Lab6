This is Lab 5 for SYSC 4806.

Here is the lab solution which is unchanged from Lab 4, but for the addition of Travis CI and Heroku Deploy.

Travis CI for this project can be seen at: https://travis-ci.org/github/DwangDistracted/SYSC4806_Lab5
Heroku Deploy for this project can be seen at: https://dashboard.heroku.com/apps/dwang-heroku-app-name-wooot-ye